import express from "express";
import { getNow, get3d, getAlerts } from "./lib/qweather.js";

export const router = express.Router();

router.get("/ping", (req, res) => res.json({ ok: true, service: "weather" }));

router.get("/weather/now", async (req, res) => {
  const city = String(req.query.city || "");
  const data = await getNow(city);
  res.json(data);
});

router.get("/weather/3d", async (req, res) => {
  const city = String(req.query.city || "");
  const data = await get3d(city);
  res.json(data);
});

router.get("/weather/alerts", async (req, res) => {
  const city = String(req.query.city || "");
  const data = await getAlerts(city);
  res.json(data);
});