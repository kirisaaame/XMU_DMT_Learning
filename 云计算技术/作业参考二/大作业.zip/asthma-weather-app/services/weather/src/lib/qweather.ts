import { MOCK_3D, MOCK_ALERTS, MOCK_NOW } from "./mock-data";

// --- API调用逻辑 (当前未激活) ---
const KEY = process.env.QWEATHER_KEY;
const USE_REAL_API = KEY && KEY !== 'your_qweather_key';
const BASE_URL = "https://devapi.qweather.com/v7";

async function fetchJson(url: string) {
  console.log(`Fetching: ${url}`);
  const resp = await fetch(url, { headers: { "User-Agent": "asthma-app" } });
  if (!resp.ok) {
    const text = await resp.text();
    console.error(`QWeather Error: ${resp.status} - ${text}`);
    throw new Error(`QWeather HTTP ${resp.status}`);
  }
  return resp.json();
}

async function lookupCity(cityName: string) {
  if (!KEY) throw new Error("QWEATHER_KEY not set");
  if (!cityName) throw new Error("城市名称是必填项");

  try {
    const url = `https://geoapi.qweather.com/v2/city/lookup?location=${encodeURIComponent(cityName)}&key=${KEY}`;
    const data = await fetchJson(url);
    if (data.code !== "200" || !data.location || data.location.length === 0) {
      throw new Error("找不到城市");
    }
    // Return the ID of the first result
    return data.location[0].id;
  } catch (e: any) {
    console.error(`城市查询失败 "${cityName}": ${e.message}`);
    throw e;
  }
}

// Helper to resolve location to cityId
async function resolveCityId(location: string) {
    // If location is all digits, assume it's an ID. Otherwise, look it up.
    if (/^\d+$/.test(location)) {
        return location;
    }
    return await lookupCity(location);
}

// --- 导出函数 ---

export async function getNow(location: string) {
  console.log(`获取当前天气 for ${location}, 使用模拟数据`);
  return Promise.resolve(MOCK_NOW);
}

export async function get3d(location: string) {
  console.log(`获取3天预报 for ${location}, 使用模拟数据`);
  return Promise.resolve(MOCK_3D);
}

export async function getAlerts(location: string) {
  console.log(`获取天气预警 for ${location}, 使用模拟数据`);
  return Promise.resolve(MOCK_ALERTS);
}