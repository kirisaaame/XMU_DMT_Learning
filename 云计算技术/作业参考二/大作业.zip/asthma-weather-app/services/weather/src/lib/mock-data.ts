// services/weather/src/lib/mock-data.ts

export const MOCK_CITY_ID = "101010100"; // 北京

export const MOCK_NOW = {
  cityId: MOCK_CITY_ID,
  now: {
    obsTime: new Date().toISOString(),
    temp: "14",
    feelsLike: "13",
    icon: "150", // 晴 (夜晚)
    text: "晴",
    wind360: "90",
    windDir: "东风",
    windScale: "4",
    windSpeed: "18",
    humidity: "65",
    precip: "0.0",
    pressure: "1016",
    vis: "16",
    cloud: "10",
    dew: "8",
  },
  aqi: {
    value: "45",
    category: "良",
    color: "#f0cc35"
  },
  summary: "今晚晴。明天多云，温度和昨天差不多（19°），有风，空气一般。",
  source: "mock-data",
  link: "http://localhost",
};

export const MOCK_3D = {
  cityId: MOCK_CITY_ID,
  daily: [
    {
      fxDate: new Date().toISOString().split("T")[0],
      sunrise: "06:50",
      sunset: "17:30",
      moonrise: "18:00",
      moonset: "06:00",
      moonPhase: "盈凸月",
      tempMax: "19",
      tempMin: "13",
      iconDay: "101",
      textDay: "多云",
      iconNight: "150",
      textNight: "晴",
      wind360Day: "90",
      windDirDay: "东风",
      windScaleDay: "3-4",
      windSpeedDay: "15",
      wind360Night: "45",
      windDirNight: "东北风",
      windScaleNight: "3-4",
      windSpeedNight: "12",
      humidity: "60",
      precip: "0.0",
      pressure: "1018",
      vis: "20",
      uvIndex: "4",
    },
    {
      fxDate: new Date(Date.now() + 86400000).toISOString().split("T")[0],
      tempMax: "18",
      tempMin: "12",
      textDay: "多云",
      textNight: "多云",
      iconDay: "101",
      iconNight: "151",
    },
    {
      fxDate: new Date(Date.now() + 2 * 86400000).toISOString().split("T")[0],
      tempMax: "16",
      tempMin: "8",
      textDay: "晴",
      textNight: "晴",
      iconDay: "100",
      iconNight: "150",
    },
    {
      fxDate: new Date(Date.now() + 3 * 86400000).toISOString().split("T")[0],
      tempMax: "14",
      tempMin: "8",
      textDay: "晴",
      textNight: "晴",
      iconDay: "100",
      iconNight: "150",
    },
    {
      fxDate: new Date(Date.now() + 4 * 86400000).toISOString().split("T")[0],
      tempMax: "19",
      tempMin: "9",
      textDay: "晴",
      textNight: "多云",
      iconDay: "100",
      iconNight: "151",
    }
  ],
  source: "mock-data",
  link: "http://localhost",
};

export const MOCK_ALERTS = {
  cityId: MOCK_CITY_ID,
  warning: [
    {
      id: "1",
      sender: "气象局",
      pubTime: new Date().toISOString(),
      title: "大风蓝色预警",
      startTime: new Date().toISOString(),
      endTime: new Date(Date.now() + 86400000).toISOString(),
      status: "active",
      level: "Blue",
      type: "1001",
      typeName: "大风",
      text: "预计今日下午将有大风天气，请注意防范。",
      related: "",
    },
  ],
  source: "mock-data",
  link: "http://localhost",
};
