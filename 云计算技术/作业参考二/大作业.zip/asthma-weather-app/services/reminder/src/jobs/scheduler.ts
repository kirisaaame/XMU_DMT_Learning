import { Reminder } from "../models/Reminder.js";
import { User } from "../models/User.js";
import { createMailer } from "../lib/mailer.js";

function nextTime(remindTime, cycle) {
  const t = new Date(remindTime);
  if (cycle === "daily") t.setDate(t.getDate() + 1);
  else if (cycle === "weekly") t.setDate(t.getDate() + 7);
  else return null; // once
  return t;
}

export function startScheduler() {
  const mailer = createMailer();
  if (!mailer) {
    console.warn("SMTP not configured. Emails will not be sent.");
  }

  setInterval(async () => {
    try {
      const now = new Date();
      const due = await Reminder.find({
        status: "Active",
        remind_time: { $lte: now }
      }).limit(50);

      if (due.length > 0) {
        console.log(`Found ${due.length} due reminders.`);
      }

      for (const r of due) {
        // 1) 找用户邮箱
        const u = await User.findById(r.user_id);
        if (mailer && u?.email) {
          console.log(`Sending email to ${u.email} for reminder ${r._id}`);
          try {
            await mailer.sendMail({
              from: process.env.SMTP_FROM || process.env.SMTP_USER,
              to: u.email,
              subject: "用药提醒",
              text: `提醒内容：${r.medication}\n时间：${now.toISOString()}`
            });
          } catch (err) {
            console.error(`Failed to send email to ${u.email}:`, err);
          }
        } else if (!u?.email) {
          console.warn(`User ${r.user_id} has no email.`);
        }

        // 2) 更新下一次或过期
        const nt = nextTime(r.remind_time, r.repeat_cycle);
        if (nt) {
          r.remind_time = nt;
          console.log(`Rescheduled reminder ${r._id} to ${nt}`);
        } else {
          r.status = "Expired";
          console.log(`Expired reminder ${r._id}`);
        }
        await r.save();
      }
    } catch (e) {
      console.error("Scheduler error:", e);
    }
  }, 60 * 1000);

  console.log("scheduler started");
}