import mongoose from "mongoose";

const UserSchema = new mongoose.Schema(
  {
    username: { type: String, unique: true, index: true },
    password_hash: { type: String, required: true },
    email: { type: String },
    city_preference: { type: String }
  },
  { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);

export const User = mongoose.model("User", UserSchema);