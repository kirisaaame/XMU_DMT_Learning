import mongoose from "mongoose";

const ReminderSchema = new mongoose.Schema(
  {
    user_id: { type: mongoose.Schema.Types.ObjectId, index: true, required: true },
    medication: { type: String, required: true },
    remind_time: { type: Date, index: true, required: true },
    repeat_cycle: { type: String, default: "once" }, // once/daily/weekly
    status: { type: String, default: "Active" }       // Active/Expired/Cancelled
  },
  { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);

export const Reminder = mongoose.model("Reminder", ReminderSchema);