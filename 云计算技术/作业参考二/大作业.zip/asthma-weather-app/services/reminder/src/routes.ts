import express from "express";
import bcrypt from "bcryptjs";
import { User } from "./models/User.js";
import { Reminder } from "./models/Reminder.js";
import { signToken, requireAuth } from "./lib/auth.js";

export const router = express.Router();

router.get("/ping", (req, res) => res.json({ ok: true, service: "reminder" }));

// Auth
router.post("/auth/register", async (req, res) => {
  try {
    const { username, password, email } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ error: "Username and password are required" });
    }

    const existing = await User.findOne({ username });
    if (existing) {
      return res.status(409).json({ error: "Username already exists" });
    }

    const password_hash = await bcrypt.hash(String(password), 10);
    const user = await User.create({ username, password_hash, email });
    res.json({ id: user._id, username: user.username });
  } catch (e: any) {
    console.error("Register error:", e);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/auth/login", async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ error: "Username and password are required" });
    }

    const user = await User.findOne({ username });
    if (!user) return res.status(401).json({ error: "Invalid credentials" });

    const ok = await bcrypt.compare(String(password), user.password_hash);
    if (!ok) return res.status(401).json({ error: "Invalid credentials" });

    const token = signToken({ uid: String(user._id), username: user.username });
    res.json({ token, username: user.username });
  } catch (e: any) {
    console.error("Login error:", e);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Reminders
router.get("/reminders", requireAuth, async (req: any, res) => {
  try {
    const uid = req.user.uid;
    const list = await Reminder.find({ user_id: uid }).sort({ remind_time: 1 });
    res.json(list);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post("/reminders", requireAuth, async (req: any, res) => {
  try {
    const uid = req.user.uid;
    const { medication, remind_time, repeat_cycle } = req.body || {};
    
    if (!medication || !remind_time) {
      return res.status(400).json({ error: "Medication and remind_time are required" });
    }

    const item = await Reminder.create({
      user_id: uid,
      medication,
      remind_time: new Date(remind_time),
      repeat_cycle: repeat_cycle || "once",
      status: "Active"
    });
    res.json(item);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.put("/reminders/:id", requireAuth, async (req, res) => {
  const uid = req.user.uid;
  const id = req.params.id;
  const patch = req.body || {};
  const item = await Reminder.findOneAndUpdate(
    { _id: id, user_id: uid },
    patch,
    { new: true }
  );
  res.json(item);
});

router.delete("/reminders/:id", requireAuth, async (req, res) => {
  const uid = req.user.uid;
  const id = req.params.id;
  await Reminder.deleteOne({ _id: id, user_id: uid });
  res.json({ ok: true });
});