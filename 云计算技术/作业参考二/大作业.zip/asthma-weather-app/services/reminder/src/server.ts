import express from "express";
import { router } from "./routes.js";
import { connectMongo } from "./lib/mongo.js";
import { startScheduler } from "./jobs/scheduler.js";

const app = express();
app.use(express.json());
app.use(router);

await connectMongo();
startScheduler();

app.listen(3002, () => console.log("reminder-service on :3002"));