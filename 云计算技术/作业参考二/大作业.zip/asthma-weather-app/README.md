# Asthma Weather App

## 快速开始

### 1. 环境准备
确保已安装 Docker Desktop。

### 2. 启动项目
在项目根目录下运行：
```powershell
# 复制环境变量配置
Copy-Item .env.example .env

# 启动服务 (构建并后台运行)
docker compose up -d --build
```

### 3. 验证
访问以下地址检查服务状态：
- 前端页面: http://localhost:8080
- Weather 服务状态: http://localhost:8080/api/weather/ping
- Reminder 服务状态: http://localhost:8080/api/ping

## 常见问题 (Troubleshooting)

### 端口冲突
默认网关端口已改为 **8080**，以避免与 Windows 本地端口 80 冲突。

### Docker Build 失败: "failed to resolve source metadata ... EOF"
如果你在中国大陆地区，遇到类似 `failed to do request: Head "https://registry-1.docker.io/..." : EOF` 的错误，通常是因为网络无法连接到 Docker Hub。

**解决方法：配置 Docker 镜像加速器**

1. 打开 **Docker Desktop**。
2. 点击右上角的 **设置 (Settings)** 图标（齿轮形状）。
3. 选择左侧的 **Docker Engine**。
4. 在右侧的 JSON 编辑框中，添加或修改 `registry-mirrors` 字段。你可以尝试以下配置：
   ```json
   {
     "builder": {
       "gc": {
         "defaultKeepStorage": "20GB",
         "enabled": true
       }
     },
     "experimental": false,
     "registry-mirrors": [
       "https://docker.m.daocloud.io",
       "https://huecker.io",
       "https://dockerhub.timeweb.cloud",
       "https://noohub.ru"
     ]
   }
   ```
   *(注意：如果已有其他配置，请确保 JSON 格式正确，不要丢失原有配置)*
5. 点击右下角的 **Apply & restart**。
6. 等待 Docker 重启完成后，再次运行 `docker compose up -d --build`。

### 4. 针对中国大陆用户的优化
本项目已预置以下优化以解决网络问题：
- **Docker 镜像源**: Dockerfile 中已使用 `docker.m.daocloud.io` 镜像源。
- **NPM 镜像源**: 构建过程中已配置 `registry.npmmirror.com`。
- **TypeScript 运行**: 后端服务使用 `tsx` 直接运行 TypeScript 代码，无需额外编译步骤。
