<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import { getNow, get3d, getAlerts } from '../api/weather'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

const city = ref('厦门') // 默认城市
const weather = ref<any>(null)
const forecast = ref<any>(null)
const alerts = ref<any>(null)
const loading = ref(false)
const error = ref('')
let map: L.Map | null = null

async function initMap() {
  if (map) return;
  
  // 默认定位到厦门
  map = L.map('weather-map').setView([24.4798, 118.0894], 10);

  // 使用高德地图瓦片（国内访问更快）
  L.tileLayer('https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}', {
    subdomains: ['1', '2', '3', '4'],
    attribution: '&copy; 高德地图'
  }).addTo(map);

  // 修复图标路径问题
  const icon = L.icon({
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });

  // 添加一个示例标记
  L.marker([24.4798, 118.0894], { icon }).addTo(map)
    .bindPopup('厦门市')
    .openPopup();
}

async function loadWeather() {
  if (!localStorage.getItem('token')) {
    error.value = '请先登录以查看天气信息。'
    return
  }
  loading.value = true
  error.value = ''
  try {
    const [w, f, a] = await Promise.all([
      getNow(city.value),
      get3d(city.value),
      getAlerts(city.value)
    ])
    weather.value = w
    forecast.value = f
    alerts.value = a
    
    // 初始化地图
    nextTick(() => {
      initMap();
    });

  } catch (e: any) {
    error.value = '无法加载天气数据，请检查城市ID或稍后再试。'
    console.error(e);
  } finally {
    loading.value = false
  }
}

onMounted(loadWeather)
</script>

<template>
  <div class="home-container">
    <div class="main-content">
      <!-- 左侧：天气详情卡片 -->
      <div class="weather-details">
        <div class="search-bar">
          <input v-model="city" placeholder="输入城市中文名或ID" />
          <button @click="loadWeather">搜索</button>
        </div>

        <div v-if="loading" class="loading-indicator">正在加载...</div>
        <div v-if="error" class="error-message">{{ error }}</div>

        <div v-if="!error && weather && weather.now" class="weather-card main-card">
          <div class="card-header">
            <h2>{{ city }}</h2>
            <span class="update-time">{{ new Date(weather.now.obsTime).toLocaleTimeString() }} 更新</span>
          </div>
          
          <div class="current-weather-display">
            <div class="weather-icon-large">
              <!-- 这里可以使用实际的天气图标，暂时用emoji代替 -->
              <span v-if="weather.now.text.includes('晴')">☀️</span>
              <span v-else-if="weather.now.text.includes('云')">☁️</span>
              <span v-else-if="weather.now.text.includes('雨')">🌧️</span>
              <span v-else>🌤️</span>
            </div>
            <div class="temp-display">
              <span class="temp-value">{{ weather.now.temp }}°</span>
              <span class="weather-text">{{ weather.now.text }}</span>
            </div>
            <div class="aqi-badge" v-if="weather.aqi">
              AQI {{ weather.aqi.category }}
            </div>
          </div>

          <p class="summary" v-if="weather.summary">{{ weather.summary }}</p>

          <div class="details-grid">
            <div class="detail-item">
              <span class="label">风向</span>
              <span class="value">{{ weather.now.windDir }} {{ weather.now.windScale }}级</span>
            </div>
            <div class="detail-item">
              <span class="label">湿度</span>
              <span class="value">{{ weather.now.humidity }}%</span>
            </div>
            <div class="detail-item">
              <span class="label">体感</span>
              <span class="value">{{ weather.now.feelsLike }}°</span>
            </div>
            <div class="detail-item">
              <span class="label">气压</span>
              <span class="value">{{ weather.now.pressure }} hPa</span>
            </div>
          </div>
        </div>

        <div v-if="forecast && forecast.daily" class="forecast-list">
          <div v-for="day in forecast.daily" :key="day.fxDate" class="forecast-item">
            <div class="forecast-date">
              <span class="day-name">{{ new Date(day.fxDate).toLocaleDateString('zh-CN', { weekday: 'short' }) }}</span>
              <span class="date-text">{{ new Date(day.fxDate).toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }) }}</span>
            </div>
            <div class="forecast-icon">
              <span v-if="day.textDay.includes('晴')">☀️</span>
              <span v-else-if="day.textDay.includes('云')">☁️</span>
              <span v-else-if="day.textDay.includes('雨')">🌧️</span>
              <span v-else>🌤️</span>
            </div>
            <div class="forecast-temp">
              <span class="max">{{ day.tempMax }}°</span>
              <span class="separator">/</span>
              <span class="min">{{ day.tempMin }}°</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 右侧：地图 -->
      <div class="map-container">
        <div id="weather-map"></div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.home-container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 1rem;
  height: calc(100vh - 80px); /* 减去导航栏高度 */
}

.main-content {
  display: flex;
  gap: 1.5rem;
  height: 100%;
}

.weather-details {
  flex: 0 0 400px; /* 固定宽度 */
  display: flex;
  flex-direction: column;
  gap: 1rem;
  overflow-y: auto;
}

.map-container {
  flex: 1;
  background: #e0e0e0;
  border-radius: 12px;
  overflow: hidden;
  position: relative;
}

#weather-map {
  width: 100%;
  height: 100%;
}

.search-bar {
  display: flex;
  gap: 0.5rem;
}

.search-bar input {
  flex: 1;
  padding: 0.8rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
}

.search-bar button {
  padding: 0 1.5rem;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
}

.weather-card {
  background: linear-gradient(135deg, #f6f8fa 0%, #e9ecef 100%);
  padding: 1.5rem;
  border-radius: 16px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-bottom: 1rem;
}

.card-header h2 {
  margin: 0;
  font-size: 1.8rem;
  color: #333;
}

.update-time {
  font-size: 0.8rem;
  color: #888;
}

.current-weather-display {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
}

.weather-icon-large {
  font-size: 4rem;
}

.temp-display {
  display: flex;
  flex-direction: column;
}

.temp-value {
  font-size: 3.5rem;
  font-weight: bold;
  line-height: 1;
  color: #333;
}

.weather-text {
  font-size: 1.2rem;
  color: #666;
}

.aqi-badge {
  background: #f0cc35;
  color: #fff;
  padding: 0.2rem 0.6rem;
  border-radius: 4px;
  font-weight: bold;
  font-size: 0.9rem;
  align-self: flex-start;
  text-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.summary {
  font-size: 0.95rem;
  color: #555;
  line-height: 1.5;
  margin-bottom: 1.5rem;
  background: rgba(255,255,255,0.5);
  padding: 0.8rem;
  border-radius: 8px;
}

.details-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
}

.detail-item {
  display: flex;
  justify-content: space-between;
  padding: 0.5rem;
  background: rgba(255,255,255,0.6);
  border-radius: 6px;
}

.detail-item .label {
  color: #888;
}

.detail-item .value {
  font-weight: 500;
  color: #333;
}

.forecast-list {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}

.forecast-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: white;
  padding: 1rem;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.03);
}

.forecast-date {
  display: flex;
  flex-direction: column;
}

.day-name {
  font-weight: bold;
  color: #333;
}

.date-text {
  font-size: 0.8rem;
  color: #999;
}

.forecast-icon {
  font-size: 1.5rem;
}

.forecast-temp {
  font-weight: 500;
}

.forecast-temp .max {
  color: #333;
}

.forecast-temp .min {
  color: #999;
  margin-left: 0.3rem;
}

.separator {
  color: #ddd;
  margin: 0 0.2rem;
}
</style>