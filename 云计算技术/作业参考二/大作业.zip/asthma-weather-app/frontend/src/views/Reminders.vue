<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { listReminders, createReminder, deleteReminder } from '../api/reminder'

interface Reminder {
  _id: string;
  medication: string;
  remind_time: string;
  repeat_cycle: string;
  status: 'Active' | 'Expired';
}

const reminders = ref<Reminder[]>([])
const loading = ref(false)
const error = ref('')

// Form state
const newMedication = ref('')
const newRemindTime = ref('')

async function loadReminders() {
  loading.value = true
  error.value = ''
  try {
    reminders.value = await listReminders() as Reminder[]
  } catch (e: any) {
    error.value = '无法加载提醒，请稍后重试。'
    console.error(e)
  } finally {
    loading.value = false
  }
}

async function handleAddReminder() {
  if (!newMedication.value || !newRemindTime.value) {
    alert('请填写完整的药品名称和提醒时间。')
    return
  }
  try {
    await createReminder({
      medication: newMedication.value,
      remind_time: newRemindTime.value,
    })
    newMedication.value = ''
    newRemindTime.value = ''
    await loadReminders() // Refresh the list
  } catch (e: any) {
    error.value = '创建提醒失败。'
    console.error(e)
  }
}

async function handleDeleteReminder(id: string) {
  if (!confirm('确定要删除这个提醒吗？')) return
  try {
    await deleteReminder(id)
    await loadReminders() // Refresh the list
  } catch (e: any) {
    error.value = '删除提醒失败。'
    console.error(e)
  }
}

onMounted(loadReminders)
</script>

<template>
  <div class="reminders-container">
    <div class="card add-form">
      <h3>添加新的用药提醒</h3>
      <form @submit.prevent="handleAddReminder">
        <div class="input-group">
          <label for="medication">药品名称</label>
          <input id="medication" v-model="newMedication" placeholder="例如：信必可都保" required />
        </div>
        <div class="input-group">
          <label for="remindTime">提醒时间</label>
          <input id="remindTime" type="datetime-local" v-model="newRemindTime" required />
        </div>
        <button type="submit" class="btn-primary">添加提醒</button>
      </form>
    </div>

    <div v-if="loading" class="loading-indicator">正在加载提醒...</div>
    <div v-if="error" class="error-message">{{ error }}</div>

    <div class="reminders-list">
      <h3>我的提醒列表</h3>
      <div v-if="!loading && reminders.length === 0" class="empty-state">
        <p>暂无用药提醒，请在上方添加。</p>
      </div>
      <div v-else class="list-items">
        <div v-for="r in reminders" :key="r._id" class="card item">
          <div class="item-details">
            <strong>{{ r.medication }}</strong>
            <p>时间: {{ new Date(r.remind_time).toLocaleString() }}</p>
            <span class="status" :class="r.status.toLowerCase()">{{ r.status === 'Active' ? '有效' : '已过期' }}</span>
          </div>
          <button @click="handleDeleteReminder(r._id)" class="btn-danger">删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.reminders-container {
  max-width: 800px;
  margin: 0 auto;
}

.card {
  background: #fff;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.05);
  margin-bottom: 1.5rem;
}

.add-form h3 {
  margin-top: 0;
}

.input-group {
  margin-bottom: 1rem;
}

.input-group label {
  display: block;
  margin-bottom: 0.5rem;
}

.input-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

.btn-primary, .btn-danger {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 4px;
  color: white;
  cursor: pointer;
  font-size: 1rem;
}

.btn-primary {
  background-color: #28a745;
}
.btn-primary:hover {
  background-color: #218838;
}

.btn-danger {
  background-color: #dc3545;
}
.btn-danger:hover {
  background-color: #c82333;
}

.loading-indicator, .error-message, .empty-state {
  text-align: center;
  padding: 2rem;
  font-size: 1.2rem;
  color: #555;
}

.error-message {
  color: #d93025;
}

.reminders-list h3 {
  border-bottom: 2px solid #eee;
  padding-bottom: 0.5rem;
  margin-bottom: 1rem;
}

.item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.status {
  font-weight: bold;
  padding: 0.2rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
}
.status.active {
  color: #28a745;
  background-color: #e9f7ec;
}
.status.expired {
  color: #6c757d;
  background-color: #f8f9fa;
}
</style>