<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { login, register } from '../api/auth'

const router = useRouter()
const username = ref('')
const password = ref('')
const email = ref('')
const isRegister = ref(false)
const error = ref('')

async function handleSubmit() {
  error.value = ''
  try {
    if (isRegister.value) {
      await register({ username: username.value, password: password.value, email: email.value })
      isRegister.value = false
      alert('注册成功！请登录。')
    } else {
      const res: any = await login({ username: username.value, password: password.value })
      localStorage.setItem('token', res.token)
      localStorage.setItem('username', res.username)
      router.push('/')
    }
  } catch (e: any) {
    error.value = e.message
  }
}
</script>

<template>
  <div class="login-container">
    <div class="form-box">
      <h2>{{ isRegister ? '创建账户' : '登录' }}</h2>
      <form @submit.prevent="handleSubmit">
        <div class="input-group">
          <label for="username">用户名</label>
          <input id="username" v-model="username" required />
        </div>
        <div class="input-group">
          <label for="password">密码</label>
          <input id="password" type="password" v-model="password" required />
        </div>
        <div v-if="isRegister" class="input-group">
          <label for="email">邮箱</label>
          <input id="email" type="email" v-model="email" required />
        </div>
        <button type="submit" class="btn-primary">{{ isRegister ? '注册' : '登录' }}</button>
      </form>
      <p v-if="error" class="error-message">{{ error }}</p>
      <button @click="isRegister = !isRegister" class="btn-secondary">
        {{ isRegister ? '已有账户？去登录' : '没有账户？去注册' }}
      </button>
    </div>
  </div>
</template>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 80vh;
  background-color: #f0f2f5;
}

.form-box {
  background: #fff;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 400px;
  text-align: center;
}

h2 {
  margin-bottom: 1.5rem;
  color: #333;
}

.input-group {
  margin-bottom: 1.5rem;
  text-align: left;
}

.input-group label {
  display: block;
  margin-bottom: 0.5rem;
  color: #555;
}

.input-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box; /* Important for padding */
}

.btn-primary {
  width: 100%;
  padding: 0.75rem;
  border: none;
  border-radius: 4px;
  background-color: #007bff;
  color: white;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.3s;
}

.btn-primary:hover {
  background-color: #0056b3;
}

.btn-secondary {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: transparent;
  color: #555;
  font-size: 1rem;
  cursor: pointer;
  margin-top: 1rem;
  transition: background-color 0.3s;
}

.btn-secondary:hover {
  background-color: #f0f0f0;
}

.error-message {
  color: #d93025;
  margin-top: 1rem;
}
</style>
