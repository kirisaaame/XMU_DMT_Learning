<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()
const loggedIn = ref(false)
const weatherPing = ref('')
const reminderPing = ref('')

// Check login status on component mount
onMounted(() => {
  loggedIn.value = !!localStorage.getItem('token')
})

watch(route, () => {
  loggedIn.value = !!localStorage.getItem('token')
})

function logout() {
  localStorage.removeItem('token')
  localStorage.removeItem('username')
  loggedIn.value = false
  router.push('/login')
}

onMounted(async () => {
  try {
    const w = await fetch('/api/weather/ping').then(r => r.json())
    weatherPing.value = w.ok ? 'OK' : 'Fail'
  } catch (e) {
    weatherPing.value = 'Error'
  }

  try {
    const r = await fetch('/api/ping').then(r => r.json())
    reminderPing.value = r.ok ? 'OK' : 'Fail'
  } catch (e) {
    reminderPing.value = 'Error'
  }
})
</script>

<template>
  <header>
    <nav>
      <h1>哮喘天气健康助手</h1>
      <div class="nav-links">
        <RouterLink to="/">天气</RouterLink>
        <RouterLink to="/reminders">用药提醒</RouterLink>
        <RouterLink v-if="!loggedIn" to="/login">登录</RouterLink>
        <a v-else @click="logout" href="#">注销</a>
      </div>
    </nav>
  </header>
  <main>
    <div class="app-container">
      <div class="status-bar">
        <small>系统状态: 天气 [{{ weatherPing }}] | 提醒 [{{ reminderPing }}]</small>
      </div>

      <RouterView />
    </div>
  </main>
</template>

<style>
/* Global Styles */
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  margin: 0;
  background-color: #f0f2f5;
}

main {
  padding: 1rem 2rem;
}
</style>

<style scoped>
header {
  background-color: #007bff;
  color: white;
  padding: 1rem 2rem;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

h1 {
  margin: 0;
  font-size: 1.5rem;
}

.nav-links a {
  color: white;
  text-decoration: none;
  margin-left: 1.5rem;
  font-size: 1rem;
  cursor: pointer;
}

.nav-links a:hover, .nav-links a.router-link-exact-active {
  text-decoration: underline;
}

.app-container { font-family: sans-serif; color: #333; }
.status-bar { padding: 0.5rem; background: #eee; font-size: 0.8rem; margin-bottom: 1rem; }
</style>