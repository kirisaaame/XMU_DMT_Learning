import { post } from './http';
import type { User } from '../models/user';

export function register(user: Partial<User>) {
  return post('/api/auth/register', user);
}

export function login(user: Partial<User>) {
  return post('/api/auth/login', user);
}
