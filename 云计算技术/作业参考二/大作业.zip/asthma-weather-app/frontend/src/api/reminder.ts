import { api, post } from "./http";

export function listReminders() {
  return api("/api/reminders");
}

export function createReminder(payload: any) {
  return post("/api/reminders", payload);
}

export function updateReminder(id: string, payload: any) {
  return api(`/api/reminders/${id}`, { method: "PUT", body: JSON.stringify(payload) });
}

export function deleteReminder(id: string) {
  return api(`/api/reminders/${id}`, { method: "DELETE" });
}