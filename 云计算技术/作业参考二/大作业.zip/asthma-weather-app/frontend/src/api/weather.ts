import { api } from "./http";

export function getNow(city: string) {
    return api(`/api/weather/weather/now?city=${encodeURIComponent(city)}`);
}

export function get3d(city: string) {
    return api(`/api/weather/weather/3d?city=${encodeURIComponent(city)}`);
}

export function getAlerts(city: string) {
    return api(`/api/weather/weather/alerts?city=${encodeURIComponent(city)}`);
}