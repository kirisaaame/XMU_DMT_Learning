export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem("token");
  const headers = new Headers(init.headers || {});
  headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);

  const resp = await fetch(path, { ...init, headers });
  if (!resp.ok) throw new Error(await resp.text());
  return resp.json();
}

export function post<T>(path: string, body: unknown): Promise<T> {
    return api(path, {
        method: 'POST',
        body: JSON.stringify(body)
    })
}