import { createRouter, createWebHistory, type RouteLocationNormalized, type NavigationGuardNext } from 'vue-router'
import Home from './views/Home.vue'
import Login from './views/Login.vue'
import Reminders from './views/Reminders.vue'

const routes = [
  { path: '/', component: Home },
  { path: '/login', component: Login },
  { 
    path: '/reminders', 
    component: Reminders,
    beforeEnter: (_to: RouteLocationNormalized, _from: RouteLocationNormalized, next: NavigationGuardNext) => {
      if (!localStorage.getItem('token')) {
        next('/login')
      } else {
        next()
      }
    }
  }
]

export const router = createRouter({
  history: createWebHistory(),
  routes
})