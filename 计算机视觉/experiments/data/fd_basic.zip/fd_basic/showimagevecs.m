% showimagevecs(IM, xdim, ydim, start, end1, fign)
function showimagevecs(IM, imH, imW, xdim, ydim, start, end1, fign)

% Show the image set if fign is valid
if (fign>0)
   figure(fign);
   for i=start:end1,
      subplot(xdim,ydim,i-start+1);
      imagesc(reshape(IM(:,i), imH, imW));
      colormap gray;
   end
end
