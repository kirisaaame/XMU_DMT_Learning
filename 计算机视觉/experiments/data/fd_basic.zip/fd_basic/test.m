%
% Testing
%
% An basic demo of gray-scale face detection 
%   via PCA sub-space method
%   using a simple 1-NN classifier
%
%
% Note:
% 1. here is the testing part
% 2. This demo serves only as a example on how to build a face 
%       detection/recognition system, this is by no means complete
%       and workable on real image data;
%
% Feb. 19, 2002
% Li Cheng @ UofA
%

% IM    the input test image
IM = double(imread('./imgs/fang.jpg'));
NumFace = 1;

load model

% START can be 1, but use to ignore smaller rectangles (level to start at)
% STEP is good at 2
% SCALEFACT is good at 1.2
START=7;
STEP=2;
LEVELS=7;
SCALEFACT=1.2;

% Setup
PYR_MAX = LEVELS;
MROWS = size(MASK,1);
MCOLS = size(MASK,2);
IROWS = size(IM, 1);
ICOLS = size(IM, 2);
RECT = [];

% Build the image pyramid
SCALE = SCALEFACT; % A good choice is 1.2
PYR{1} = IM;
XRANGE{1} = 1:1:ICOLS;
YRANGE{1} = 1:1:IROWS;
[MX{1},MY{1}] = meshgrid(XRANGE{1}, YRANGE{1});
for i=2:PYR_MAX,
	XRANGE{i} = 1:SCALE.^(i-1):ICOLS;
	YRANGE{i} = 1:SCALE.^(i-1):IROWS;
	[MX{i},MY{i}] = meshgrid(XRANGE{i}, YRANGE{i});
	PYR{i} = interp2(MX{1}, MY{1}, PYR{1}, MX{i}, MY{i});
end

% View pyramid
%figure;
%colormap(gray);
%showimages(PYR, 2, 3, 1, 6, 1);
%drawnow;
%pause;

% Scan the pyramid
for im_num = START:PYR_MAX,
  fprintf(1, '\n\nImage Scale: %d\n', im_num);
  for im_row = 1:STEP:size(PYR{im_num},1)-MROWS+1,
    fprintf(1, '\n Row:%d', im_row);
    for im_col = 1:STEP:size(PYR{im_num},2)-MCOLS+1,
        TEST = 0;
        if bPCA==1
        	TEST = classify_1NN(PYR{im_num}, MASK, im_row, im_col,mean_ALL, U1, S1, data_proj, cFACEV, cNFACEV);
        elseif bPCA_LDA==1
        	TEST = classify_1NN_new(PYR{im_num}, MASK, im_row, im_col, mean_ALL, meanF, meanNF, U1, S1, U2, S2, dataF_proj, dataNF_proj);
        elseif bSVM==1
            TEST = classify_SVM(PYR{im_num}, MASK, im_row, im_col);
        elseif bPCA_SVM==1
            TEST = classify_PCA_SVM(PYR{im_num}, MASK, im_row, im_col, mean_ALL, U1, S1);
        end
        if (TEST == 1)
            fprintf(1, '\n  ---(#SCALE,R,C): [%d] (%d,%d)  ',im_num, im_row, im_col);
            RECT = [RECT; (im_row/size(YRANGE{im_num},2))*size(YRANGE{1},2), ...                % top
                         (im_col/size(XRANGE{im_num},2))*size(XRANGE{1},2), ...                 % left
                         ((im_row+MROWS-1)/size(YRANGE{im_num},2))*size(YRANGE{1},2), ...       % bottom
                         ((im_col+MCOLS-1)/size(XRANGE{im_num},2))*size(XRANGE{1},2), ...       % right
                         TEST];                                                                 % TEST value
	    end
    end
  end
end

% Plot the bounding boxes in an image
IMR = IM;
drawbox(IMR, RECT, 1);

% post-process to eliminate these false detections
RECT = postprocess(IM, RECT, NumFace);

% plot again
IMtmp = IM;
drawbox(IMtmp, RECT, 1);
