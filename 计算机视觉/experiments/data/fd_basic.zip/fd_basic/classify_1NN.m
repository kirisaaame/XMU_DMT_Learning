%
% a simple 1-NN classifier
%
% An basic demo of gray-scale face detection 
%   via PCA sub-space method
%   using a simple 1-NN classifier
%
%
% Note:
% 1. here is the classification part
% 2. This demo serves only as a example on how to build a face 
%       detection/recognition system, this is by no means complete
%       and workable on real image data;
%
% Feb. 19, 2002
% Li Cheng @ UofA
%
function res = classify_1NN(IM, MASK, srow, scol, mean_ALL, U1, S1, data_proj, cFACEV, cNFACEV)

% 1-NN classfication scalar factor for face & non-face
% res == 1: IS a face
% res ~= 1: NOT a face
%

MASKH = size(MASK, 1);
MASKW = size(MASK, 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                              1-NN Classification
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% given a query data vector, decide if it is face by 1-NN
QUERY{1} = IM(srow:srow+MASKH-1,scol:scol+MASKW-1);                   % the fixed moving-window size
[NORM_QUERYS, SHADING] = normalize(QUERY, MASK);
QUERYV = buildimvector(NORM_QUERYS, MASK);

% project into the PCA sub-space
% QUERYV = QUERYV - mean_ALL; needn't do the mean-subtraction here!! to retain the discrimination power
Q_proj1 = (U1*inv(S1))' * QUERYV;

Q_F = Q_proj1 * ones(1, cFACEV);
Q_NF= Q_proj1 * ones(1, cNFACEV);

dataF_proj = data_proj(:,1:cFACEV);
dataNF_proj = data_proj(:,cFACEV+1:size(data_proj,2));

clear data_proj;

% two dist. measurement, we now choose the euclidean one..
                                                                 % euclidean dist.
tmp_F=sum((dataF_proj-Q_F).^2, 1);
tmp_NF=sum((dataNF_proj-Q_NF).^2, 1);

                                                                 % cosin dist. (similarity dist.)
%tmp_F = abs(Q_F_proj'*dataF_proj)/(norm(Q_F_proj)*norm(dataF_proj,'fro'));
%tmp_NF= abs(Q_NF_proj'*dataNF_proj)/(norm(Q_NF_proj)*norm(dataNF_proj,'fro'));

mintmpF = min(tmp_F);
mintmpNF= min(tmp_NF);

% find which face/non-face is the closest
% idx_F = find(tmp_F == meantmpF );
% idx_NF= find(tmp_NF== meantmpNF);

% because non-face data tend to be scattered compared to face data,
% so here we need a scalar factor to balance them

if mintmpF < mintmpNF
    %fprintf('\n the query image IS a face image');
    res = 1;
else
    res = 0;
    %fprintf('\n the query image is NOT a face image');
end
