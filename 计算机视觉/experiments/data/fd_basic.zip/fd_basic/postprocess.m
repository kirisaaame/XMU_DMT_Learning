%
% post-process to eliminate these false detections
%
%
% Note:
% 1. here is the classification part
% 2. This demo serves only as a example on how to build a face 
%       detection/recognition system, this is by no means complete
%       and workable on real image data;
%
% Feb. 19, 2002
% Li Cheng @ UofA
%
% NumFace: pre-determined #Face we want to detect
%
function res = postprocess(IM, RECT, NumFace)

[h,w] = size(IM);
NUMRect= size(RECT, 1);


% hC    : hit count
% currR : current RECT
% i,j   : current col @ row position
% currR(1), currR(3): top, bottom
% currR(2), currR(4): left, right
% currR(5): -1:false detection, 
%           0: not decided, 
%           1:NUMFace : the detection box for specific face

myRECT = (RECT);
myRECT(:,5) = zeros(NUMRect, 1);

for index = 1:NumFace
    %
    % find current max hit position
    
    MaxHit = 0; posH =0; posW = 0;
    for i=1:h
    for j=1:w
        hC = 0;
        for k=1:NUMRect
            currR = myRECT(k,:);
            if (i>currR(1) & i<currR(3) & ...
                j>currR(2) & j<currR(4) & currR(5)==0)
                hC = hC + 1;
            end
        end
    
        if hC > MaxHit
            MaxHit = hC;
            posH = i; posW = j;
        end

    end
    end
    
    % compute the overlapped area out of these overlapped boxes
    for k=1:NUMRect
        currR = myRECT(k,:);
        if (posH>currR(1) & posH<currR(3) & ...
            posW>currR(2) & posW<currR(4) & currR(5)==0)
            myRECT(k,5) = index;
        end
    end

    area = [1,1, size(IM,1), size(IM,2)];
    for k=1:NUMRect
        if myRECT(k,5) == index
            area = myrectint(area, myRECT(k,1:4));
        end
    end
    
    center = [(area(1)+area(3))/2, (area(2)+area(4))/2];
    
    % find the center of area (center), then elect only ONE box which's center closest to center, and eleminate others
    closest = 1e5; ind_closest=0;
    for k=1:NUMRect
        if myRECT(k,5) == index
            centerR = [(myRECT(k,1)+myRECT(k,3))/2, (myRECT(k,2)+myRECT(k,4))/2];
            if norm(centerR-center) < closest
                closest = norm(centerR-center);
                ind_closest = k;
            end
        end
    end
    
    for k=1:NUMRect
        if myRECT(k,5) == index & ind_closest ~= k
            myRECT(k,5) =-1;
        end
    end
end

res = [];
for k=1:NUMRect
    if myRECT(k,5)>0
        res = [res; RECT(k,:)];
    end
end


% sub routines
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function res = myrectint(area1, area2)
res = zeros(size(area1));

if (area1(1)>area2(1))
    res(1)=area1(1);
else
    res(1)=area2(1);
end;

if (area1(2)>area2(2))
    res(2)=area1(2);
else
    res(2)=area2(2);
end;

if (area1(3)<area2(3))
    res(3)=area1(3);
else
    res(3)=area2(3);
end;

if (area1(4)<area2(4))
    res(4)=area1(4);
else
    res(4)=area2(4);
end;

