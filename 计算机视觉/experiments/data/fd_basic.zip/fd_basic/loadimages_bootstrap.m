% Desc:   Loads a set of images from boosting from directory
%
%
function res = loadimages_bootstrap(IM, directory, prefix, suffix)

% #imgs already exists IM FACES
numImgs=size(IM, 2);

% cd IM this directory
old_dir=pwd;
cd(directory);

% fIMd all matched filenames
dirinfo = dir([prefix,'*.',suffix]);
found = {dirinfo.name};


% Load the image set
for i = 1:size(found,2),
    if suffix=='pgm'
        IM{i} = double(pgmRead(found{i}));
    else
      IM{numImgs+i} = double(imread(found{i}));     
    end
end

res = IM;

clear found

% cd out 
cd(old_dir);
