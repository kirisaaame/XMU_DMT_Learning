function res = scaleImg(imname, cscale, rscale, imgsavename)

if(nargin<4) imgsavename='out.PNG'; end

IM = double(imread(imname));
IROWS = size(IM, 1);
ICOLS = size(IM, 2);

PYR{1} = IM;
XRANGE{1} = 1:1:ICOLS;
YRANGE{1} = 1:1:IROWS;
[MX{1},MY{1}] = meshgrid(XRANGE{1}, YRANGE{1});

XRANGE{2} = 1:cscale:ICOLS;
YRANGE{2} = 1:rscale:IROWS;
[MX{2},MY{2}] = meshgrid(XRANGE{2}, YRANGE{2});
PYR{2} = interp2(MX{1}, MY{1}, PYR{1}, MX{2}, MY{2});

imwrite(PYR{2}/255, imgsavename)
imshow(PYR{2}/255)
