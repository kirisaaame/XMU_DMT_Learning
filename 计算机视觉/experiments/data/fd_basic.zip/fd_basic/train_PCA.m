%
% Training
%
% An basic demo of gray-scale face detection 
%   via PCA sub-space method
%   using a simple 1-NN classifier
%
%
% Note:
% 1. here is the training part
% 2. This demo serves only as a example on how to build a face 
%       detection/recognition system, this is by no means complete
%       and workable on real image data;
%
% Feb. 19, 2002
% Li Cheng @ UofA
%

% [eMin:eMax] range eigen_value & eigen_vectors we will keep
eMin = 3;
eMax = 23;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                              Image Loading
%%%
%%%
% assume training images are already preprocessed:
%   i.e. cropped (to left face pixels only) and scaled to appropriate size (18*27 i.e.)
% now load in the images and make up the training data mtx
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load the image oval mask
MASK = buildmask;
NI   = size(find(MASK),1);

% load face images, normalize, and set training vectors
                                                            % temp: only for current test query here!!!!
                                                            % need to change back if not use current query images
FACES = loadimages('./trainset/train/face/', '', 'pgm');
%FACES = loadimages_bootstrap(FACES, './bootstrap/face/','','PNG');
%FACES = augmentlr(FACES);
[NORM_FACES, SHADING] = normalize(FACES, MASK);

clear FACES SHADING

FACEV = buildimvector(NORM_FACES, MASK);
%FACER = buildresvector(NORM_FACES, FACE_T);

clear NORM_FACES

% load non-face images, normalize, and set training vectors

NFACES = loadimages('./trainset/train/non-face/', '', 'pgm');
%NFACES = loadimages_bootstrap(NFACES, './bootstrap/non-face/', '','PNG');
%NFACES = augmentlr(NFACES);
[NORM_NFACES, NSHADING] = normalize(NFACES, MASK);

clear NFACES NSHADING

NFACEV = buildimvector(NORM_NFACES, MASK);
%NFACER = buildresvector(NORM_NFACES, FACE_F);

clear NORM_NFACES

cFACEV = size(FACEV, 2);
cNFACEV = size(NFACEV, 2);


% optional --- Display images
if 0,
disp('original image data');
showimages(NORM_FACES,  5, 10, 1, 50, 1);
% showimages(NORM_NFACES, 5, 5, 1, 25, 2);
% pause;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%               Build the sub-space with eigen- vectors & values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% FACESV & NFACESV: each face is a column vector

% collect face & non_face data together
%   : each (non-)face is a column vector
ALL = [FACEV NFACEV];

clear FACEV NFACEV

mean_ALL = sum(ALL, 2)/size(ALL,2);

% mean subtracted:
data = ALL - mean_ALL *ones(1, size( ALL,2));

% get U and S from data
% as you may try&found, when using large dataset, eig() or svd() fail to reach a converged solution
% while snap-shot method (as used by Pentland et. al.) or em-pca methods can still have a good solution

% SVD
%[U1, S1, V1] = svd(data);

% eig
%[U1, S1] = eig(data*data'); S1=sqrt(S1);

% snap shot method (not implement yet, you are encouraged to implement one here!)

% EM-PCA
                                % iter: default is 20
iter = 20;
                                % for em-pca, nnedn't mean-subtraction here
[U1, S1] = empca(ALL,eMax,iter);
S1 = diag(S1);                  % S1 is a mtx now

% chop U&S to preserve only the [eMin:eMax] range of eigen- vectors & values
U1 = U1 (:, eMin:eMax);
S1 = S1 (eMin:eMax, eMin:eMax);

% project training data into sub-space
data_proj = (U1*inv(S1))' * data;


% optional --- eigen-spectra plots
if 0,
tmp1=diag(S1);
subplot(1,2,1),plot(1:length(tmp1), tmp1);
end

% optional --- now we can re-construct face by the remaining eigen data
if 0,
FACEV_recon = U1 *U1' *data(:,1:cFACEV)  + mean_ALL *ones(1, cFACEV);
NORM_FACE_recon = buildface(FACEV_recon, MASK);
disp('the reconstruction result');
showimagevecs(NORM_FACE_recon, size(MASK,1), size(MASK,2), 5, 10, 1, 50, 2);

end

save model

bPCA=1;
bPCA_LDA=0;
bSVM=0;
bPCA_SVM=0;