function drawbox(IMR, RECT, bPlot)
% Plot the bounding boxes in an image

for i=1:size(RECT,1),
  SR = ceil(RECT(i,1)); 
  ER = ceil(RECT(i,3)); 
  SC = ceil(RECT(i,2)); 
  EC = ceil(RECT(i,4));
  IMR(SR,SC:EC) = 0; 
  IMR(ER,SC:EC) = 0; 
  IMR(SR:ER,SC) = 0;
  IMR(SR:ER,EC) = 0;
end

% Plot the image
if bPlot
    figure;
    colormap(gray);
    imagesc(IMR);
    drawnow;
end