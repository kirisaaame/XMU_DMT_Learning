%%
%% buildface: from DATA and MASK, re-build the before-masked data
%%

function res = buildface(DATA, MASK)

% DATA is the the masked data (the non-zero portion of the MASK)
% MASK is a mtx containing 0&1.

imgs = size(DATA,2);
INDICES = find(MASK);

res = zeros(size(MASK(:),1),imgs);
for i=1:imgs
    tmp = MASK(:);
    tmp(INDICES)=DATA(:,i);
    res(:,i) = tmp;
end