Note:
 1. These codes serve only as a example on how to build a face 
       detection/recognition system, this is by no means complete
       and workable on real image data;
 2. part of the codes are courtesy from S. Sanner
 3. The data set is downloaded from MIT website
 4. the codes is tested OK under Matlab version 6 and Win2000 OS

Li @ Fab. 21, 2002



File Listing
============

M-Files (Main Files)
--------------------
train_PCA.m - The main script that loads all required training files,
                  builds the needed data structures, etc.

test.m      - The main image face-scanning function.


M-Files (Image Utilities)
-------------------------
buildimvector.m  - Builds an image vector from a rectangular
                   image array.
buildresvector.m - Builds a result vector to match the
                   image vector.  
buildmask.m      - Builds a rectangulary binary mask array
                   for face images.
normalize.m      - Normalizes an image by subtracting a
                   linear lighting plane and rescaling the
                   grayscale distribution histogram.
augmentlr.m      - Augments an image set with the left-right
                   flipped versions of the images.
buildface	     - from DATA and MASK, re-build the before-masked data
classify_1NN     - a simple 1-NN classifier
postprocess.m    - some simple postprocessing to reduce the amount of detected faces

M-Files (Image Loading/Display)
-------------------------------
loadimages.m     - Loads a set of images according to the
                   given pattern set.
loadimages_bootstrap.m
                 - Loads a set of images via bootstrap.
showimages.m     - Subplots a set of images in an image
                   array.
showimagevecs.m  - Subplots a set of images in an image
                   array.
pgmRead.m        - load in pgm format image.

Other Files (Files in sub-directories)
-------------------------------
mfa              - contain codes&demo for mixture of factor analyzers (a probabilistic approach for dimension reduction & classification)
JDQR             - an implementation of  eigen-decomposition method, as alternitive of eig() or eigs()
empca            - codes&demo for EXpectation-Maximization Principle Component Analysis

Note: these directories also contain related documentation for further reading

bootstrap        - directory that you can put your bootstrapped images into
imgs             - directory contains test images
out              - directory contains detected face images