% Harris Corner Detection in MATLAB

% 读取输入图像
img = imread('fruit.jpg');
grayImg = rgb2gray(img); % 转换为灰度图像

% 参数设置
sigma = 3; 
k = 0.06; 
threshold = 0.05; 

% 计算图像的梯度
[Ix, Iy] = gradient(double(grayImg));

% 计算Ix^2, Iy^2, 和 Ix*Iy
Ix2 = Ix.^2;
Iy2 = Iy.^2;
Ixy = Ix .* Iy;

% 使用高斯滤波器平滑这些值
G = fspecial('gaussian', [5, 5], sigma);
Sx2 = imfilter(Ix2, G);
Sy2 = imfilter(Iy2, G);
Sxy = imfilter(Ixy, G);

% 计算Harris响应R
detM = (Sx2 .* Sy2) - (Sxy .^ 2);
traceM = Sx2 + Sy2;
R = detM - k * (traceM .^ 2);

% 非极大值抑制
R(R < threshold*max(R(:))) = 0;

% 找到角点
corners = R > 0;

% 在原始图像上标记角点
outputImg = img;
[rows, cols] = find(corners);
for i = 1:length(rows)
    outputImg(rows(i), cols(i), :) = 255; 
    outputImg(rows(i), cols(i), 1) = 255; 
    outputImg(rows(i), cols(i), 2) = 0;   
    outputImg(rows(i), cols(i), 3) = 0;   
end

% 显示结果
imshow(grayImg);
title('输入图像');

imshow(R, []);
title('响应R图像');

imshow(outputImg);
title('检测到的角点');
