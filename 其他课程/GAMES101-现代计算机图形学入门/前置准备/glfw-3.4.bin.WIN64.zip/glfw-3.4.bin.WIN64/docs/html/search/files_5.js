var searchData=
[
  ['news_2emd_0',['news.md',['../news_8md.html',1,'']]]
];
