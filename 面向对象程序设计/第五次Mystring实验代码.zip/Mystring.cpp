#include"Mystring.h"

int myStat(char *const input)    
{
    int count=0;
    char *p=input;
    while(*p!=0)
    {
        if(*p>='a'&&*p<='z'||*p>='A'&&*p<='Z')count++;
        p++;
    }
    return count;
}
int mylength(char *const input)
{
	int count=0;
    char *p=input;
    while(*p!=0)
    {
       	count++;
        p++;
    }
    return count;
}
char *myConcat(char *const left,char*const right)
{
    char*lef=left,*rig=right;
	int l1=mylength(lef),l2=mylength(rig);
    int l=l1+l2;
    char *str=new char[l+1],*cur=str;
    int i;
    for(i=0;i<l1;i++)
    {
        *cur=*(lef++);
        cur++;
    }
    for(i=0;i<l2;i++)
    {
        *cur=*(rig++);
        cur++;
    }
    return str;
}
void myUpper(char *input)
{
    int l=mylength(input),i;
    for(i=0;i<l;i++)
    {
        if(*(input+i)>='a'&&*(input+i)<='z')
        {
            *(input+i)-=32;
        }
    }

}
void myLower(char *input)
{
    int l=mylength(input),i;
    for(i=0;i<l;i++)
    {
        if(*(input+i)>='A'&&*(input+i)<='Z')
        {
            *(input+i)+=32;
        }
    }
}
void myEncode(char *input)
{
    int l=mylength(input),i;
    for(i=0;i<l;i++)
    {
        *(input+i)+=8;
    }
}
void myDecode(char *input)   
{
    int l=mylength(input),i;
    for(i=0;i<l;i++)
    {
        *(input+i)-=8;
    }
}
