#pragma once 
#include<iostream>
using namespace std;

int myStat(char *const input);    
char *myConcat(char *const left,char*const right);
void myUpper(char *input);
void myLower(char *input);
void myEncode(char *input);
void myDecode(char *input);  
